#include <stdlib.h>	
#include <stdio.h>	
#include <math.h>
#include <time.h>
#include "tablero.h"

int main()
{
	/* COMPLETAR CODIGO */
	
}

