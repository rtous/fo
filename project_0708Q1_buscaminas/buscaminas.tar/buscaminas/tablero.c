#include <stdio.h>
#include <stdlib.h>	
#include <time.h>
#include <math.h>
#include "tablero.h"
#include "casilla.h"
#include "colores.h"


void imprimir_tablero(t_tablero t)
{
	/* COMPLETAR CODIGO */
}

void inicializar_tablero(t_tablero *pt, int nfils, int ncols, int minas)
{
	/* COMPLETAR CODIGO */
}

void realizar_jugada_en_tablero(t_tablero *p_t, int fila, int columna, char accion) {
	/* COMPLETAR CODIGO */
}

void levantar_todas(t_tablero *pt)
{	
	/* COMPLETAR CODIGO */
}

/* Y OTRAS FUNCIONES NO VISIBLES DES DE FUERA DEL MODULO... */
