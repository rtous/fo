#include <stdio.h>
#include "casilla.h"
#include "colores.h"

void imprimir_casilla(t_casilla c)
{
	/* COMPLETAR CODIGO */
}


